// config.jsx

const config = {
    baseUrl: 'http://localhost:5000',
  };
  
  export default config;
  